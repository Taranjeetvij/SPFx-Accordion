declare interface ICustomAccordionWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CustomAccordionWebPartStrings' {
  const strings: ICustomAccordionWebPartStrings;
  export = strings;
}
